# Wedding Guest Tracker — Setup Guide

Follow these steps exactly, in order. Takes about 15 minutes total.

---

## STEP 1 — Create the Google Sheet

1. Go to https://sheets.google.com
2. Click **Blank** to create a new spreadsheet
3. Rename it: click "Untitled spreadsheet" at the top → type **Wedding Guest Tracker** → press Enter
4. At the bottom, you'll see a tab called "Sheet1" — right-click it → **Rename** → type `guests` → press Enter
5. Click the **+** button at the bottom to add a new sheet → rename it `drivers`
6. Leave both sheets empty — the app will create the headers automatically
7. Copy the URL of this spreadsheet from your browser — you'll need it in Step 2

---

## STEP 2 — Set Up Google Apps Script

1. In your Google Sheet, click **Extensions** in the top menu → **Apps Script**
2. A new tab opens with a code editor. Delete everything in the editor (Ctrl+A, Delete)
3. Open the file **Code.gs** from this project
4. Copy the entire contents and paste it into the Apps Script editor
5. Click the **💾 Save** button (or Ctrl+S) — name the project **Wedding Guest Tracker**
6. Now deploy it:
   - Click **Deploy** (top right) → **New deployment**
   - Click the gear icon ⚙️ next to "Select type" → choose **Web app**
   - Fill in the fields:
     - Description: `Wedding Guest Tracker`
     - Execute as: **Me**
     - Who has access: **Anyone**
   - Click **Deploy**
7. Google will ask you to authorize — click **Authorize access** → choose your Google account → click **Allow**
8. After deployment, you'll see a screen with a **Web app URL** — it looks like:
   `https://script.google.com/macros/s/AKfycb.../exec`
9. **Copy this URL** — you'll need it when opening the app for the first time

> ⚠️ Important: Every time you edit Code.gs and want to update the live version, you must click Deploy → **Manage deployments** → edit the existing deployment → set version to **New version** → Deploy. Otherwise your changes won't take effect.

---

## STEP 3 — Get Your Gemini API Key (Free)

1. Go to https://aistudio.google.com
2. Sign in with your Google account
3. Click **Get API key** in the left sidebar
4. Click **Create API key** → choose **Create API key in new project**
5. Copy the key — it starts with `AIza...`
6. Keep this key safe — don't share it publicly

**Free tier limits (more than enough for a wedding):**
- 15 requests per minute
- 1 million tokens per day
- No credit card required

---

## STEP 4 — Host on GitHub Pages (Free)

1. Go to https://github.com and create a free account if you don't have one
2. Click the **+** button (top right) → **New repository**
3. Repository name: `wedding-guest-tracker`
4. Set to **Public** (required for free GitHub Pages)
5. Click **Create repository**
6. On the next page, click **uploading an existing file**
7. Drag and drop both files: `index.html` and `Code.gs`
8. Click **Commit changes**
9. Now enable GitHub Pages:
   - Click **Settings** tab in your repository
   - Click **Pages** in the left sidebar
   - Under "Source" → select **Deploy from a branch**
   - Branch: **main** | Folder: **/ (root)**
   - Click **Save**
10. After 1-2 minutes, your site will be live at:
    `https://YOUR-USERNAME.github.io/wedding-guest-tracker`

---

## STEP 5 — Open the App and Configure

1. Open your GitHub Pages URL in any browser
2. You'll see the setup screen asking for two things:
   - **Apps Script Web App URL** — paste the URL from Step 2
   - **Gemini API Key** — paste the key from Step 3
3. Click **Open Dashboard**
4. The app will connect to your Google Sheet and initialize the headers automatically
5. You're ready to go!

> The credentials are saved in your browser's local storage. You only need to enter them once per device. Use the ⚙️ Settings button anytime to update them.

---

## STEP 6 — Add Your Drivers to the Sheet

Before the wedding days, add your drivers directly in the Google Sheet:

1. Open your **Wedding Guest Tracker** Google Sheet
2. Click the **drivers** tab
3. The app will have created these headers in Row 1:
   `driver_id | driver_name | driver_phone | car_type | car_token | capacity | assigned`
4. Fill in each driver starting from Row 2. Example:

| driver_id | driver_name | driver_phone | car_type | car_token | capacity | assigned |
|---|---|---|---|---|---|---|
| D001 | Suresh Kumar | 9876543210 | Innova | 1042 | 7 | no |
| D002 | Ramesh Das | 9876543211 | Ertiga | 2031 | 6 | no |
| D003 | Bikash Roy | 9876543212 | Tempo Traveller | 3099 | 12 | no |

> Fill driver_id manually as D001, D002 etc. The rest is free text.

---

## HOW TO USE — Day of Event

**Adding a guest:**
1. Tap **+ Add Guest** button
2. Tap the upload zone and select a ticket image or PDF
3. Gemini auto-fills the details — verify them
4. Fill in remaining fields (group name, phone, car assignment)
5. Tap **Save Guest Group**

**Checking live status:**
- Open a card by tapping it
- Tap **🔄 Refresh Status** — Gemini searches live train/flight status
- The status strip color updates automatically (green/amber/red)

**Marking dispatch:**
- Tap **🚗 Mark Dispatched** when you've told the driver to leave

**Marking picked up:**
- Tap **✅ Picked Up** when the guest is in the car
- The card moves to the Completed section at the bottom

**If you marked something by mistake:**
- Open the Completed section → tap the card → tap **↩ Mark Active**

---

## SHARING WITH CO-COORDINATOR

Just share the GitHub Pages URL. Anyone who opens it will see the setup screen and needs to enter the same Apps Script URL and Gemini API key. Share those two values over WhatsApp with your co-coordinator.

---

## TROUBLESHOOTING

**"Could not connect to Google Sheet"**
→ Your Apps Script URL is wrong, or you didn't deploy it as a Web App with "Anyone" access. Redo Step 2.

**Cards not saving**
→ Open Apps Script → Deploy → Manage deployments → check it's deployed and the URL matches what you entered in the app.

**Gemini extraction not working**
→ Check your API key is correct. Go to aistudio.google.com and verify the key is active.

**App shows blank after entering credentials**
→ Clear your browser's local storage: open browser console → type `localStorage.clear()` → refresh the page → re-enter credentials.

**GitHub Pages not loading**
→ Wait 5 minutes after enabling it. If still not working, check the repository is Public.
